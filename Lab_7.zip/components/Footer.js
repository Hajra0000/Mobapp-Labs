import * as React from 'react';
import { StyleSheet, View, Text } from 'react-native';

export default function Footer() {
return (
<View
    style={{
    backgroundColor: 'teal',
    marginBottom: 0,
    }}>
    <Text
        style={{
        fontSize: 18,
        color: 'black',
        textAlign: 'center',
        }}>
        All rights reserved
    </Text>
</View>
);
}