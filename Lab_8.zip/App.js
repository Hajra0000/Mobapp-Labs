import { StatusBar } from 'expo-status-bar';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';
import Welcome from './components/Welcome';
import WelcomeScreen from './components/WelcomeScreen';

export default function App() {
  return (
    <>
    <Welcome/>
    <WelcomeScreen/>
    </>

  );
}
