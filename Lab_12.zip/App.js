import React from 'react';
import Navigator from './routes/homestack';
export default function App() {
return (
<Navigator />
);
}