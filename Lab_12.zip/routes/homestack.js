import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import Home from '../screens/home';
import BookDetails from '../screens/bookDetail';
import Intro from '../screens/intro';

const screens = {
Home: {
screen: Home,
},
BookDetails: {
screen: BookDetails,
},
Intro: {
  screen: Intro,
},
};
// home stack navigator screens
const HomeStack = createStackNavigator(screens);
export default createAppContainer(HomeStack);