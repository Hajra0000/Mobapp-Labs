import React from 'react';
import { StyleSheet, View, Text, Button } from 'react-native';
import { globalStyles } from '../styles/global';

export default function Intro({ navigation }) {
const pressHandler = () => {
navigation.goBack();
}
return (
<View style={globalStyles.container}>
<Text>Hello World! My Name is Eisha Tir Raazia</Text>
<Button title='go back' onPress={pressHandler} />
</View>
);
}